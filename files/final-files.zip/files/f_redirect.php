<?php
if (isset($_POST['confirm']))
header("Location:fslot_insert.php");
if(isset($_POST['change']))
header("Location:f_slots.html");
?>