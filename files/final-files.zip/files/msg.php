<!DOCTYPE html>
	<html>
	<head>
		<style type="text/css">.outline{position:absolute; top:0; left:0; width:100%; height:100%; }
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

 li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
.button {
    background-color: #CA226B; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

li a:hover {
    background-color: #111;
}
</style>
	</head>
	<body>
<div align="center" class="outline">
	<ul>
  <li><a class="active" href="index.html">Home</a></li>
  <li><a href="http://www.nitandhra.ac.in/nitandhra/">NITAP</a></li>
  <li><a href="Contact.html">Contact</a></li>
  <li><a href="About.html">About</a></li>
  </ul> 
</div>
  </body>
  </html>

<?php
session_start();
$sub=$_SESSION['sub_id'];

include 'db_connection.php';
$conn = OpenCon();
//$r=$_SESSION['r'];
/*$i=0;
foreach($_POST['c']  as $c){
//$query1 = "UPDATE $sub SET `PRESENT`='1',`MARKS`='1',`COMMENTS`='$comments' WHERE `ROLL_NO`=$r"; 
  //$result1=mysqli_query($conn, $query1);
  echo $c[0];
  $i=$i+1;
}
*/
echo "<form method = 'post' action = 'f_index.html'>"; # action = 'f_selection.html'>";#here change action = s.php
	
$c=0;
$rn=array();
foreach($_SESSION['rno'] as $r){
	$rn[$c]=$r;
	$c=$c+1;
}
for ($i=0; $i<3; $i++){
$pr= $_POST['p'][$i];	
$mr= $_POST['m'][$i];
$co =$_POST['c'][$i];
if($pr==0){
	$mr=0;
	$co=" ";	
}
$query1 = "UPDATE $sub SET `PRESENT`=$pr,`MARKS`=$mr,`COMMENTS`='$co' WHERE `ROLL_NO`=$rn[$i]"; 
  $result1=mysqli_query($conn, $query1);;
 
 }
 echo "<body style='background-color:#00334d'>";
 echo "<p style='color:white;font-size:30px; position: absolute;left: 43%;top:20%;'>successfully updated</p>";
 
 echo "<input class='button' type = 'submit' name = 'SUBMIT' style='position: absolute;left: 44%;top:40%;' value = 'Go to home page '>";

 

//	header("Location: index.html");
 ?> 