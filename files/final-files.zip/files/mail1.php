<?php	
	function sendOTP($email,$body) {
		include("phpmailer/class.phpmailer.php");
 include("phpmailer/class.smtp.php");
 include("phpmailer/PHPMailerAutoload.php");
 $mail = new PHPMailer();
 $mail->IsSMTP(); // set mailer to use SMTP
 $mail->Host = "smtp.gmail.com"; // specify main and backup server
 $mail->SMTPSecure = 'tls';
 $mail->Port = 465; // set the port to use
 $mail->SMTPDebug = 0;
 $mail->SMTPAuth = true; // turn on SMTP authentication
 $mail->Username = "dwdmproject3@gmail.com"; // your SMTP username or your gmail username
 $mail->Password = "dwdmproject@3"; // your SMTP password or your gmail password
 $from = "dwdmproject3@gmail.com"; // Reply to this email
 $to=$email; // Recipients email ID
 $name="NIT AP ADMIN"; // Recipient's name
 $mail->From = $from;
 $mail->FromName = "NIT AP ADMIN"; // Name to indicate where the email came from when the recepient received
 $mail->AddAddress($to,$name);
 $mail->AddReplyTo($from,"NIT AP ADMIN");
 $mail->WordWrap = 50; // set word wrap
 $mail->IsHTML(true); // send as HTML
 $mail->Subject = "NIT AP ADMIN";
 $mail->Body = $body;	
 $mail->AltBody = $body;
 $result = $mail->Send();
		return $result;
}

?>