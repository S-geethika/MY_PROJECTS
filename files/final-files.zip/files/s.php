<?php
#session_start();
 include 'db_connection.php';
$conn = OpenCon();
/*
if(isset($_POST['sc']))
{
#echo "hi";
$query = "SELECT * FROM toc_slots WHERE ROLL_NO !=0"; 
$result=mysqli_query($conn, $query);
$num=mysqli_num_rows($result);
while($slot = mysqli_fetch_assoc($result))
	{    $r=$slot["ROLL_NO"];
$p= $_POST['p'];
$m = $_POST['m'];
$c= $_POST['c'];
$sql = "UPDATE toc_slots SET PRESENT = '$p', MARKS = '$m', COMMENTS = '$c' WHERE ROLL_NO = '$r' ";
$retval = mysqli_query( $conn,$sql );

if(! $retval )
{
  die('Could not update data: ' . mysql_error());
}
echo "Updated data successfully\n";

}

}
*/
#if(isset($_POST['ur']))
#{
#$query = "SELECT * FROM toc_slots WHERE ROLL_NO !=0"; 
#$result=mysqli_query($conn, $query);
#while($slot = mysqli_fetch_assoc($result))
#	{    $r=$slot["ROLL_NO"];
#$query1 = "SELECT MAIL_ID  FROM student_reg  WHERE ROLL_NO ='$r' "; 
#$result1=mysqli_query($conn, $query1);
#$slot1 = mysqli_fetch_assoc($result1);
 #$email=$slot1["MAIL_ID"];
 #$body="ASSIGNMENT RESULTS  : ROLL NO : $r "<br>MARKS : $slot1["MARKS"]<br>COMMENTS : $slot1["COMMENTS"]";		
		#require_once("mail_function.php");
	#	$mail_status = sendOTP($email,$body);
#}
#}
		?>