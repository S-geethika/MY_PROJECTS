<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$message="";
if(count($_POST)>0) {
	$query = mysqli_query($conn,"SELECT SUBJECT_ID FROM facuty_reg WHERE USER_NAME='" . $_POST['data'] . "'  and PASSWORD = '". $_POST['pwd']."'");	
		$count  = mysqli_num_rows($query);
	$obj = mysqli_fetch_object($query);
	if($count==0) {
		$message = "Invalid Username or Password!";
		echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'retry' value = 'change'></td></tr>";
	
		//CloseCon($conn);
		
	} 
	
	else {
		$message = "You are successfully authenticated!";
		$sub_id=$obj->SUBJECT_ID;
		//echo $sub_id;
		$_SESSION['sub_id'] = $sub_id;
		header('Location: f_selection.html');
exit;
	   	}
	echo $message;
}
CloseCon($conn);

?>
