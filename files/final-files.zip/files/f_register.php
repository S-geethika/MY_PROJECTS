<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
 //require_once("mail_function1.php");
echo "Connected Successfully";
 $sub_id = $_POST['sub_id'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$dept=$_POST['dept'];
$email=$_POST['email'];
$_SESSION['mail']=$email;
$pwd=md5($_POST['pwd']);
$c_pwd=$_POST['c_pwd'];
$phno=$_POST['phno'];
$sql = "INSERT INTO facuty_reg (SUBJECT_ID,FIRST_NAME,LAST_NAME,USER_NAME,DEPARTMENT,MAIL_ID,PASSWORD,CONFIRM_PASSWORD,PHONE_NUMBER) VALUES ('$sub_id', '$fname', '$lname','$uname' ,'$dept', '$email', '$pwd', '$c_pwd', '$phno')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
#$body="REGISTRATION DETAILS :<br> SUBJECT ID : $sub_id<br>FIRST NAME : $fname<br>LAST NAME : $lname<br>USER NAME : $uname<br>DEPARTMENT : $dept<br>PASSWORD $pwd<br>";			 
#echo $body;
#$mail_status = sendOTP($email,$body);
header('Location: freg_success.html'); 
CloseCon($conn);
?>