<?php

function OpenCon()
{
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "geethu1808";
	$db= "se_project";
	$conn = new mysqli($dbhost,$dbuser,$dbpass,$db) or die("connection FAILED!! : %s\n". $conn->error);
	return $conn;
}

function CloseCon($conn)
{
	$conn->close();
}
?>
