<!DOCTYPE html>
	<html>
	<head>
		<style type="text/css">.outline{position:absolute; top:0; left:0; width:100%; height:100%; }
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

 li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
.button {
    background-color: #CA226B; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}


li a:hover {
    background-color: #111;
}
</style>
	</head>
	<body>
<div align="center" class="outline">
	<ul>
  <li><a class="active" href="index.html">Home</a></li>
  <li><a href="http://www.nitandhra.ac.in/nitandhra/">NITAP</a></li>
  <li><a href="Contact.html">Contact</a></li>
  <li><a href="About.html">About</a></li>
  </ul> 
</div>
  </body>
  </html>


<?php
//--source-------https://www.daniweb.com/programming/web-development/threads/331121/use-radio-button-to-select-row-of-returned-query-data

include 'db_connection.php';
$conn = OpenCon();
session_start();
//$sub=$_SESSION['sub'];
$sub=$_SESSION['sub'];
//echo $sub;
 $query = "SELECT * FROM $sub WHERE ROLL_NO =0"; 
$result=mysqli_query($conn, $query);
$num=mysqli_num_rows($result);
echo "<body style='background-color:#00334d'>";
 echo "<p style='color:white;font-size:30px; position: absolute;bottom: 0;left: 50%;width: 100%;height: 75%;'>SUBJECT ID : $sub </p>";

//echo "SUBJECT ID : $sub";
echo " ";
//$query1 = "SELECT FIRST_NAME FROM facuty_reg WHERE SUBJECT_ID=$sub'";	
//$result1=mysqli_query($conn, $query1);
	//	$count  = mysqli_num_rows($query1);
	//$obj = mysqli_fetch_object($result1);
//$fname=$obj->FIRST_NAME;
//echo "INSTRUCTOR NAME :";
//echo  $fname ;
echo "Available Slots";
	echo "<form method = 'post' action = 'toc_confirm.php'>";
	//echo "<table width = '50%' border = '1'>";
	echo "<table width = '50%' border = '1'  style='position: absolute;bottom: 0;font-size:20px;left: 0;width: 100%;height: 70%;color : white;'>";
	
	echo "<tr>";
		echo "<td></td>";
		echo "<td>ID</td>";		
		echo "<td>DATE</td>";
		echo "<td>START TIME</td>";
		echo "<td>END TIME</td>";
		echo "</tr>";
		$slot = mysqli_fetch_assoc($result);
		$i=$slot["ID"];
		$d=$slot["DATE"];
		$s=$slot["START_TIME"];
		$e=$slot["END_TIME"];
		echo "<tr>";
			
			echo "<td><input type = 'radio' name = 'ID' value = '".$slot["ID"]."' ></td>";
			$_SESSION['ID'] = $slot["ID"];
			echo "<td>$i</td>";			
			echo "<td>$d</td>";
			echo "<td>$s</td>";
			echo "<td>$e</td>";
		echo "</tr>";
	while($slot = mysqli_fetch_assoc($result))
	{    $i=$slot["ID"];
		$d=$slot["DATE"];
		$s=$slot["START_TIME"];
		$e=$slot["END_TIME"];
		echo "<tr>";
			
			echo "<td><input type = 'radio' name = 'ID' value = '".$slot["ID"]."'></td>";
			$_SESSION['ID'] = $slot["ID"];
			echo "<td>$i</td>";			
			echo "<td>$d</td>";
			echo "<td>$s</td>";
			echo "<td>$e</td>";
		echo "</tr>";
	}
	echo "<tr><td colspan = '5' align = 'center' ><input class='button' type = 'submit' name = 'SUBMIT' value = 'SUBMIT'></td></tr>";
	echo "</table>";
	echo "</form>";
	?>
