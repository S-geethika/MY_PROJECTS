<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$r=$_SESSION['roll_no'];
$dep=$_SESSION['DEPARTMENT'];
 $sub=$_POST['sub'];
  $_SESSION['sub']=$_POST['sub'];
 $sq="SELECT  COUNT(*) as 'num' FROM '$sub' WHERE 'ROLL_NO' ='$r'"; 
 $result=$conn->query($sq);
$value = mysqli_fetch_object($result);




if($value> 1)
{
    
	echo "<form method = 'post' action = 'redirect1.php'>";
	echo "you have already selected a slot ";
	//echo "<button type="button" id="stu" value="change" name="change"><a href="change.php">Student</a></button>";
 	//echo "<button type="button" id="st" value="logout" name="logout"><a href="index.html">Student</a></button>";
 	echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'change' value = 'change'></td></tr>";
	echo "<tr><input type = 'submit' name = 'logout' value = 'logout'></td></tr>";

}
else
		{
		    
			//echo "else";
		header("Location:toc.php");
}
?>	