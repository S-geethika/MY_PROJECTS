<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$r=$_SESSION['roll_no'];  
$sub= $_SESSION['sub'];
//echo $r;
 $q = "SELECT ID FROM $sub WHERE ROLL_NO =$r"; 
 $id1=mysqli_query($conn, $q);
//$q1="UPDATE TABLE toc_slots set ROLL_NO=0  WHERE ID=(SELECT ID FROM toc_slots WHERE ROLL_NO =$r)";
$id=(int)$id1;
$q1="UPDATE  $sub set ROLL_NO=0  WHERE ID=$id";
$res=mysqli_query($conn, $q1);
echo "id is $id" ;
echo $sub;
header("Location:toc.php");
//$num1=mysqli_num_rows($result1);
?>
