<!DOCTYPE html>
	<html>
	<head>
		<style type="text/css">.outline{position:absolute; top:0; left:0; width:100%; height:100%; }
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

 li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
.button {
    background-color: #CA226B; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

li a:hover {
    background-color: #111;
}
</style>
	</head>
	<body>
<div align="center" class="outline">
	<ul>
  <li><a class="active" href="index.html">Home</a></li>
  <li><a href="http://www.nitandhra.ac.in/nitandhra/">NITAP</a></li>
  <li><a href="Contact.html">Contact</a></li>
  <li><a href="About.html">About</a></li>
  </ul> 
</div>
  </body>
  </html>

	

<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$i=$_SESSION['ID'];
$r=$_SESSION['roll_no'];  
$sub=$_SESSION['sub'];
$sql = "UPDATE $sub set ROLL_NO='$r' WHERE ID='$i'";
echo "<form method = 'post' action = 'index.html'>";

if ($conn->query($sql) === TRUE) {
    //echo "slot alloted successfully";
echo "<body style='background-color:#00334d'>";

	echo "<p style='color:white;font-size:30px; position: absolute;left: 40%;top:20%;'>Slot alloted successfully </p>";

	//echo "<tr><td colspan = '5' class='button' align = 'center'><input type = 'submit' name = 'logout' value = 'logout' ></td></tr>";
//			echo "<tr> <td colspan = '5' align = 'absolute'  style='color:white;font-size:30px; position: absolute;top=80%;left: 50%;width: 50%;height: 75%;'><input class='button' type = 'submit' name = 'SUBMIT' value = 'SUBMIT'></td></tr>";
	//echo "<tr><td colspan = '5' class='button'  style='color:white;font-size:30px; position: absolute;top=45%;left: 50%;width: 100%;height: 75%;'><input type = 'submit' name = 'logout' value = 'logout' ></td></tr>";
	echo "<input class='button' type = 'submit' name = 'SUBMIT' style='position: absolute;left: 45%;top:40%;' value = 'LOGOUT'>";

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
CloseCon($conn);
 
?>
