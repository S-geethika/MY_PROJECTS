<!DOCTYPE html>
	<html>
	<head>
		<style type="text/css">.outline{position:absolute; top:0; left:0; width:100%; height:100%; }
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

 li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
.button {
    background-color: #CA226B; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}top : 50%; 

li a:hover {
    background-color: #111;
}
</style>
	</head>
	<body>
<div align="center" class="outline">
	<ul>
  <li><a class="active" href="index.html">Home</a></li>
  <li><a href="http://www.nitandhra.ac.in/nitandhra/">NITAP</a></li>
  <li><a href="Contact.html">Contact</a></li>
  <li><a href="About.html">About</a></li>
  </ul> 
</div>
  </body>
  </html>

	<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$id=$_POST['ID'];
echo "<body style='background-color:#00334d'>";
// echo "<p style='color:#CA226B;font-size:30px; position: absolute;bottom: 0;left: 50%;width: 100%;height: 75%;'>SELECTED SLOT </p>";

echo "<form method = 'post' action = 'redirect.php'>";
$sub=$_SESSION['sub'];
	$query = "SELECT * FROM $sub WHERE ID = '".$_POST['ID']."'";
	$result=mysqli_query($conn, $query);
    $slot = mysqli_fetch_assoc($result);
	$_SESSION['ID']=$_POST['ID'];
	$d=$slot["DATE"];
		$s=$slot["START_TIME"];
		$e=$slot["END_TIME"];
	echo "<table width = '50%' border = '1'  style='position: absolute;top : 10%;font-size:20px;left: 30%;width: 30%;height: 20%;color : white;'>";
	
	//echo "<table border = '1' cellpadding = '4' cellspacing = '4'>";
		echo "<tr><td align = 'center' colspan = '2'><b>SLOT DETAILS</b></td></tr>";
		
        echo "<tr><td >Date </td><td><b>$d</b></td></tr>";
		echo "<tr><td >Start Time </td><td><b>$s</b></td></tr>";
		echo "<tr><td >End Time </td><td><b>$e</b></td></tr>";
	//	echo "<tr><td colspan = '5' style='position: absolute;top : 60%;font-size:20px;left: 60%;width: 30%;height: 20%;color : white;'><input type = 'submit' class='button' name = 'confirm' value = 'confirm'></td></tr>";
	echo "<tr><td  ><input type = 'submit' class='button' name = 'confirm' value = 'confirm'> <td><input type = 'submit' class='button' name = 'change' value = 'change'></td></tr>";

			echo "</table>";
			
	
?>