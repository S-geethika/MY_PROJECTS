<?php
session_start();
 include 'db_connection.php';
$conn = OpenCon();
$sub_id=$_SESSION['sub_id'];

	header("Location:toc_schedule.php");

?>