<?php
session_start();
include 'db_connection.php';
$conn = OpenCon();
$message="";


if(count($_POST)>0) {
	$query = mysqli_query($conn,"SELECT * FROM student_reg WHERE USER_NAME='" . $_POST['data'] . "'  and PASSWORD = '". $_POST['pwd']."'");	
	$count  = mysqli_num_rows($query);
$obj = mysqli_fetch_object($query);
	if($count==0) {
		$message = "Invalid Username or Password!";
		echo " ";
		echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'retry' value = 'retry' ></td></tr>";
		//echo "<button type="button" id="stu" value="retry" name="retry"><a href="s_login.html">Student</a></button>";
 	echo "<form method = 'post' action = 's_login.html'>";
		} 
	
	else {
		$message = "You are successfully authenticated!";
		$roll_no=$obj->ROLL_NO;
		$_SESSION['roll_no'] = $roll_no;
		$dep=$obj->DEPARTMENT;
		$_SESSION['DEPARTMENT']=$dep;
		if($dep=='cse')
		{		header('Location: s_cse.html');}
	else if($dep=='ece')
	{
		header('Location: s_ece.html');
		}
	else if($dep=='eee')
	{
		header('Location: s_eee.html');
		}
		
		
		
exit;
	   	}
	echo $message;
}
CloseCon($conn);

?>
