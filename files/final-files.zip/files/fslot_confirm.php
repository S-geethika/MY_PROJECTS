<?php
session_start();
 include 'db_connection.php';
$conn = OpenCon();


 $date = $_POST['date'];
$s1=$_POST['1s'];
$s2=$_POST['2s'];
$s3=$_POST['3s']; 
$s4=$_POST['4s'];
$s5=$_POST['5s']; 

$e1=$_POST['1e']; 
$e2=$_POST['2e']; 
$e3=$_POST['3e']; 
$e4=$_POST['4e'];
$e5=$_POST['5e']; 

$_SESSION['date']= $date;
$_SESSION['s1']= $s1;
$_SESSION['s2']= $s2;
$_SESSION['s3']= $s3;
$_SESSION['s4']= $s4;
$_SESSION['s5']= $s5;

$_SESSION['e1']= $e1;
$_SESSION['e2']= $e2;
$_SESSION['e3']= $e3;
$_SESSION['e4']= $e4;
$_SESSION['e5']= $e5;

$d=date('y-m-d');
$dur=$_POST['dur'];
$dur="00:".$_POST['dur'];
$d1=(strtotime($e1)-strtotime($s1))/60;
$d1="00:".$d1.":00";
$d2=(strtotime($e2)-strtotime($s2))/60;
$d2="00:".$d1.":00";
$d3=(strtotime($e3)-strtotime($s3))/60;
$d3="00:".$d1.":00";
$d4=(strtotime($e4)-strtotime($s4))/60;
$d4="00:".$d1.":00";
$d5=(strtotime($e5)-strtotime($s5))/60;
$d5="00:".$d1.":00";
if($s1<$e1&&$s2<$e2&&$s3<$e3&&$s4<$e4&&$s5<$e5&&$date>$d&&$s2>$s1&&$s2>$e1&&$s3>$s2&&$s3>$e2&&$s4>$s3&&$s4>$e3&&$s5>$s4&&$s5>$e4)
{
    echo "<form method = 'post' action = 'f_redirect.php'>";
$sub_id=$_SESSION['sub_id'];
echo "<table border = '1' cellpadding = '4' cellspacing = '4'>";
		echo "<tr><td align = 'center' colspan = '2'><b>SLOT DETAILS</b></td></tr>";
		 echo "<tr><td align = 'right'>DATE </td><td><b>$date</b></td>";
		
        echo "<tr><td align = 'right'>START TIME </td><td><b>$s1</b></td>";
		echo "<td align = 'right'>END TIME </td><td><b>$e1</b></td></tr>";
		 echo "<tr><td align = 'right'>START TIME </td><td><b>$s2</b></td>";
		echo "<td align = 'right'>END TIME </td><td><b>$e2</b></td></tr>";
		 echo "<tr><td align = 'right'>START TIME </td><td><b>$s3</b></td>";
		echo "<td align = 'right'>END TIME </td><td><b>$e3</b></td></tr>";
		 echo "<tr><td align = 'right'>START TIME </td><td><b>$s4</b></td>";
		echo "<td align = 'right'>END TIME </td><td><b>$e4</b></td></tr>";
		 echo "<tr><td align = 'right'>START TIME </td><td><b>$s5</b></td>";
		echo "<td align = 'right'>END TIME </td><td><b>$e5</b></td></tr>";
		
			echo "</table>";
			echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'confirm' value = 'confirm'></td></tr>";
echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'change' value = 'change'></td></tr>";
}
else
{
header('Location:error.php');
}	

?>