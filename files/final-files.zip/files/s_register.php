<?php
include 'db_connection.php';
 session_start();
$conn = OpenCon();
 
//echo "Connected Successfully";

 //$_SESSION['roll_no'] = $_POST['roll_no'];
$roll_no== $_POST['roll_no'];
 $fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$dept=$_POST['dept'];
$sem=$_POST['sem'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$c_pwd=$_POST['c_pwd'];
$phno=$_POST['phno'];
echo"$sub_id";
$sql = "INSERT INTO student_reg (ROLL_NO,FIRST_NAME,LAST_NAME,USER_NAME,DEPARTMENT,SEMESTER,MAIL_ID,PASSWORD,CONFIRM_PASSWORD,PHONE_NUMBER) VALUES ('$roll_no', '$fname', '$lname','$uname' '$dept','$sem' '$email', '$pwd', '$c_pwd', '$phno')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
header('Location: sreg_success.html');
CloseCon($conn);
 
?>