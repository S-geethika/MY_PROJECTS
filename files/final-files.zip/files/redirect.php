<?php
if (isset($_POST['confirm']))
header("Location:insert.php");
if(isset($_POST['change']))
{
header("Location:change.php");
}
?>