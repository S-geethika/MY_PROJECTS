<?php
include 'db_connection.php';
$conn = OpenCon();
//$email=$_SESSION['mail'];
		// generate OTP
		$otp = rand(100000,999999);
		$otp="OTP for registration is :".$otp."<br> please don't share it with any one.<br>thank you";
		// Send OTP
		require_once("mail1.php");
			$mail_status = sendOTP("siriaugust18@gmail.com",$otp);
			
			?>
	
			
