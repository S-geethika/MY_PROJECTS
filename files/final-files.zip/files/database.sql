-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2018 at 04:02 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cs301`
--

CREATE TABLE `cs301` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs301`
--

INSERT INTO `cs301` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-12-12', '08:00:00.00000', '08:20:00.00000', 0, NULL, 0, ''),
(2, '2018-08-02', '06:30:00.00000', '06:42:00.00000', 411554, 1, 9.3, 'can improve good'),
(3, '2018-12-14', '02:00:00.00000', '02:20:00.00000', 411566, 0, 0, ''),
(4, '2018-12-14', '03:00:00.00000', '03:20:00.00000', 411528, 0, 0, ''),
(5, '2018-12-14', '03:30:00.00000', '03:50:00.00000', 0, NULL, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `cs302`
--

CREATE TABLE `cs302` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float(2,2) NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cs302`
--

INSERT INTO `cs302` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-09-01', '03:00:00.00000', '03:25:00.00000', 411528, 0, 0.00, ''),
(2, '2018-12-14', '03:00:00.00000', '03:20:00.00000', 0, NULL, 0.00, ''),
(3, '2018-12-14', '05:00:00.00000', '05:20:00.00000', 411566, NULL, 0.00, ''),
(4, '2018-11-10', '05:00:00.00000', '05:20:00.00000', 411548, NULL, 0.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `ec301`
--

CREATE TABLE `ec301` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float(2,2) NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ec301`
--

INSERT INTO `ec301` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-12-14', '04:00:00.00000', '04:20:00.00000', 611502, NULL, 0.00, ''),
(2, '2018-12-14', '04:40:00.00000', '05:00:00.00000', 0, NULL, 0.00, ''),
(3, '2018-12-14', '06:00:00.00000', '06:20:00.00000', 0, NULL, 0.00, ''),
(4, '2018-12-14', '03:00:00.00000', '03:20:00.00000', 0, NULL, 0.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `ec302`
--

CREATE TABLE `ec302` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float(2,2) NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ec302`
--

INSERT INTO `ec302` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-12-08', '11:00:00.00000', '11:20:00.00000', 0, NULL, 0.00, ''),
(2, '2018-12-08', '10:00:00.00000', '10:20:00.00000', 611534, NULL, 0.00, ''),
(3, '2018-12-07', '09:00:00.00000', '09:20:00.00000', 0, NULL, 0.00, ''),
(4, '2018-12-07', '13:00:00.00000', '13:20:00.00000', 0, NULL, 0.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `ee301`
--

CREATE TABLE `ee301` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float(2,2) NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ee301`
--

INSERT INTO `ee301` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-12-08', '08:00:00.00000', '08:20:00.00000', 0, NULL, 0.00, ''),
(2, '2018-12-05', '09:00:00.00000', '09:20:00.00000', 511506, NULL, 0.00, ''),
(3, '2018-12-08', '10:00:00.00000', '10:20:00.00000', 0, NULL, 0.00, ''),
(4, '2018-12-05', '10:00:00.00000', '10:20:00.00000', 511501, NULL, 0.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `ee302`
--

CREATE TABLE `ee302` (
  `ID` int(5) NOT NULL,
  `DATE` date NOT NULL,
  `START_TIME` time(5) NOT NULL,
  `END_TIME` time(5) NOT NULL,
  `ROLL_NO` int(6) DEFAULT NULL,
  `PRESENT` tinyint(1) DEFAULT NULL,
  `MARKS` float NOT NULL,
  `COMMENTS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ee302`
--

INSERT INTO `ee302` (`ID`, `DATE`, `START_TIME`, `END_TIME`, `ROLL_NO`, `PRESENT`, `MARKS`, `COMMENTS`) VALUES
(1, '2018-12-07', '08:00:00.00000', '08:20:00.00000', 511507, 0, 0, ''),
(2, '2018-12-10', '10:00:00.00000', '10:20:00.00000', 0, NULL, 0, ''),
(3, '2018-12-11', '10:00:00.00000', '10:20:00.00000', 0, NULL, 0, ''),
(4, '2018-12-09', '11:00:00.00000', '11:20:00.00000', 0, NULL, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `facuty_reg`
--

CREATE TABLE `facuty_reg` (
  `SUBJECT_ID` varchar(5) NOT NULL,
  `FIRST_NAME` varchar(20) DEFAULT NULL,
  `LAST_NAME` text,
  `USER_NAME` varchar(10) NOT NULL,
  `DEPARTMENT` text NOT NULL,
  `MAIL_ID` varchar(20) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `CONFIRM_PASSWORD` varchar(30) NOT NULL,
  `PHONE_NUMBER` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facuty_reg`
--

INSERT INTO `facuty_reg` (`SUBJECT_ID`, `FIRST_NAME`, `LAST_NAME`, `USER_NAME`, `DEPARTMENT`, `MAIL_ID`, `PASSWORD`, `CONFIRM_PASSWORD`, `PHONE_NUMBER`) VALUES
('cs301', 'jaya lakshmi', 'golla', 'jaya12', 'cse', 'lakshmi7@gmail.com', 'jaya1234', 'jaya1234', 6143341467),
('ee302', 'Lakshmi', 'Shreta', 'lakshmi123', 'eee', 'lalli234@gmail.com', 'lalli123', 'lalli123', 9876574536),
('EE301', 'Raman', 'Gudaparthi', 'ramg', 'eee', 'ramg@gmail.c', 'stardust1', 'stardust1', 2147483647),
('EC302', 'ramya', 'srisha', 'ramya933', 'ece', 'ramyasrha@gmail.com', 'ram54', 'ram54', 9147483637),
('CS302', 'ravi', 'bolli', 'ravi34', 'cse', 'ravicse@gmail.com', 'ravii@cse', 'ravii@cse', 9493428588),
('EE302', 'sai', 'gowtham', 'spsg333', 'eee', 'spsg333@gmail.com', 'spsg@3', 'spsg@3', 8074419828),
('EC301', 'yamuna', 'pavanijula', 'yamunap', 'ece', 'yamuna18@gmail.com', 'qw345fder', 'qw345fder', 9474836472);

-- --------------------------------------------------------

--
-- Table structure for table `otp_expiry`
--

CREATE TABLE `otp_expiry` (
  `id` int(11) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `is_expired` int(11) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `otp_expiry`
--

INSERT INTO `otp_expiry` (`id`, `otp`, `is_expired`, `create_at`) VALUES
(0, '197805', 1, '2017-11-13 18:25:45'),
(0, '285833', 1, '2017-11-13 18:26:15'),
(0, '481912', 0, '2017-11-13 18:27:46'),
(0, '625613', 0, '2017-11-13 18:27:53'),
(0, '990936', 0, '2017-11-13 18:27:58'),
(0, '178332', 1, '2017-11-13 18:28:46'),
(0, '821060', 0, '2017-11-13 18:29:26'),
(0, '684774', 0, '2017-11-13 18:30:49'),
(0, '165203', 0, '2017-11-13 18:32:03'),
(0, '936911', 1, '2017-11-13 18:35:43'),
(0, '101428', 0, '2017-11-13 18:36:02'),
(0, '261361', 1, '2017-11-14 17:23:21'),
(0, '997802', 1, '2017-11-14 17:23:43'),
(0, '702435', 0, '2017-11-14 17:55:59'),
(0, '328295', 1, '2017-11-14 19:25:22'),
(0, '235818', 0, '2017-11-14 19:29:08'),
(0, '352465', 1, '2017-11-14 19:29:12'),
(0, '395339', 0, '2017-11-14 19:30:43'),
(0, '779559', 1, '2017-11-14 19:32:40'),
(0, '851657', 0, '2017-11-14 19:33:00');

-- --------------------------------------------------------

--
-- Table structure for table `student_reg`
--

CREATE TABLE `student_reg` (
  `ROLL_NO` int(6) NOT NULL,
  `FIRST_NAME` text,
  `LAST_NAME` text,
  `USER_NAME` text NOT NULL,
  `DEPARTMENT` text NOT NULL,
  `SEMESTER` int(1) NOT NULL,
  `MAIL_ID` varchar(30) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `CONFIRM_PASSWORD` varchar(30) NOT NULL,
  `PHONE_NUMBER` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_reg`
--

INSERT INTO `student_reg` (`ROLL_NO`, `FIRST_NAME`, `LAST_NAME`, `USER_NAME`, `DEPARTMENT`, `SEMESTER`, `MAIL_ID`, `PASSWORD`, `CONFIRM_PASSWORD`, `PHONE_NUMBER`) VALUES
(411503, 'Lavanya', 'abothula', 'lavtpty', 'cse', 4, 'lavang@gmail.com', 'love2234', 'love2234', 9945129753),
(411566, 'Geethika', 'Siripurapu', 'siri1808', 'cse', 4, 'siriaugust18@gmail.com', 'get@1911', 'get@1911', 8179529622),
(511501, 'Sravya', 'Achanta', 'sravya1998', 'eee', 4, 'sravya1998@gmail.com', '11111111', '11111111', 9867645691),
(511526, 'Hemalatha', 'konikala', 'hemak', 'eee', 4, 'hemag@gmail.com', 'hemag678', 'hemag678', 8976523451),
(611503, 'Sabitha', 'Gandam', 'Sgandam', 'ece', 4, 'sabithag@gmail.com', 'sabi1234', 'sabi1234', 9345129753),
(611540, 'Pragathi', 'kionum', 'prag12', 'ece', 4, 'pragapriya@gmail.com', 'priya679', 'priya679', 9867645693);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cs301`
--
ALTER TABLE `cs301`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cs302`
--
ALTER TABLE `cs302`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ec301`
--
ALTER TABLE `ec301`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ec302`
--
ALTER TABLE `ec302`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ee301`
--
ALTER TABLE `ee301`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ee302`
--
ALTER TABLE `ee302`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `facuty_reg`
--
ALTER TABLE `facuty_reg`
  ADD PRIMARY KEY (`USER_NAME`);

--
-- Indexes for table `student_reg`
--
ALTER TABLE `student_reg`
  ADD PRIMARY KEY (`ROLL_NO`),
  ADD UNIQUE KEY `mail id` (`MAIL_ID`),
  ADD UNIQUE KEY `p no` (`PHONE_NUMBER`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
