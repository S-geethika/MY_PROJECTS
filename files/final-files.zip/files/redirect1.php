<?php
if (isset($_POST['logout']))
header("Location:index.html");
if(isset($_POST['change']))
header("Location:change.php");
?>