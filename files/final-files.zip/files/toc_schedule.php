	<!DOCTYPE html>
	<html>
	<head>
		<style type="text/css">.outline{position:absolute; top:0; left:0; width:100%; height:100%; }
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

 li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}
</style>
	</head>
	<body>
<div align="center" class="outline">
	<ul>
  <li><a class="active" href="index.html">Home</a></li>
  <li><a href="http://www.nitandhra.ac.in/nitandhra/">NITAP</a></li>
  <li><a href="Contact.html">Contact</a></li>
  <li><a href="About.html">About</a></li>
  </ul> 
</div>
  </body>



<?php
include_once("toc_schedule.php");
$m=array();
$c=array();
$p=array();
$rn=array();
$i=0;
//--source-------https://www.daniweb.com/programming/web-development/threads/331121/use-radio-button-to-select-row-of-returned-query-data
include 'db_connection.php';
$conn = OpenCon();
session_start();
$sub=$_SESSION['sub_id'];
 $query = "SELECT * FROM $sub WHERE ROLL_NO !=0"; 
$result=mysqli_query($conn, $query);
$num=mysqli_num_rows($result);
echo "<body style='background-color:#00334d'>";
 echo "<p style='color:white;font-size:30px; position: absolute;top:9%;left: 48%;width: 80%;height: 89%;'>SCHEDULE</p>";
 echo " ";
	echo "<form method = 'post' action = 'msg.php'>"; # action = 'f_selection.html'>";#here change action = s.php
	echo "<table width = '50%' border = '1'  style='position: absolute;top:20%;left: 10%;width: 80%;height: 70%;color : white;'>";
	echo "<tr>";
		
		echo "<td style=color:white>ID</td>";		
		echo "<td>DATE</td>";
		echo "<td>START TIME</td>";
		echo "<td>END TIME</td>";
		echo "<td>ROLL NO</td>";
		echo "<td>PRESENT</td>";
		echo "<td>MARKS</td>";
		echo "<td>COMMENTS</td>";
		echo "</tr>";

	//$slot = mysqli_fetch_assoc($result);
/*		$i=$slot["ID"];
		$d=$slot["DATE"];
		$s=$slot["START_TIME"];
		$e=$slot["END_TIME"];
		$r=$slot["ROLL_NO"];
		$p=$slot["PRESENT"];
		$m=$slot["MARKS"];
		$c=$slot["COMMENTS"];
		echo "<tr>";
					//echo "<td><input type = 'radio' name = 'ID' value = '".$slot["ID"]."' ></td>";
			$_SESSION['ID'] = $slot["ID"];
			echo "<td>$i</td>";			
			echo "<td>$d</td>";
			echo "<td>$s</td>";
			echo "<td>$e</td>";
			echo "<td>$r</td>";
			echo "<td><input type = 'text' name = 'p' value =$p></td>";
			echo "<td><input type = 'text' name = 'm' value =$m></td>";
			echo "<td><input type = 'text' name = 'c' value =$c ></td>";
		
		echo "</tr>";
*/
		while($slot = mysqli_fetch_assoc($result))
	{    $i=$slot["ID"];
		$d=$slot["DATE"];
		$s=$slot["START_TIME"];
		$e=$slot["END_TIME"];
		$r=$slot["ROLL_NO"];
		$p=$slot["PRESENT"];
		$m=$slot["MARKS"];
		$c=$slot["COMMENTS"];
		echo "<tr>";
		$cnt=0;
			#echo "<td><input type = 'text' name = 'ID' value = '".$slot["ID"]."'></td>";
			$_SESSION['ID'] = $slot["ID"];
			echo "<td>$i</td>";			
			echo "<td>$d</td>";
			echo "<td>$s</td>";
			echo "<td>$e</td>";
			echo "<td>$r</td>";
			$rn[$i]=$r;
			//echo "<td>$rn[$i]</td>";
			//echo $rn[$i];
			$i=$i+1;
			?>
			<td><input type = "text" name = "p[]" ></td>
			<td><input type = "text" name = "m[]"></td>
			<td><input type = "text" name = "c[]" ><td>

			<?php
			 		
	
  }
	
	
	//echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'sc' value = 'SAVE CHANGES'></td>";
		echo "<input class='button' type = 'submit' name = 'SUBMIT' style='position: absolute;left: 45%;top:105%;' font-size=20px; value = 'Save Changes'>";

	echo "</table>";
	echo "</form>";
	$_SESSION['rno']=$rn
	?>
	
	  </html>
