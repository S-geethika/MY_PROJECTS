<?php
session_start();
 include 'db_connection.php';
$conn = OpenCon();
echo "<form method = 'post' action = 'f_slots.html'>";
echo "error!! <br>Invalid time slot value<br>";
echo "You probably made the following the errors : <br>";
echo "1.start time greater than end time next line<br> 2.start time is same as end time<br> 3.incorrect date <br>4.slot duration did not satisfy entered time slot duration<br>5.present slot should be greater than previous slot.<br>6.two slot timings can't be same<br>";

echo "<tr><td colspan = '5' align = 'center'><input type = 'submit' name = 'go back' value = 'go back'></td></tr>";

?>