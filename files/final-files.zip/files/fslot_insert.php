<?php
session_start();
 include 'db_connection.php';
$conn = OpenCon();
//static $a =12,$b=13,$c=14,$d=15,$e=16; 
$date = $_SESSION['date'];
$s1=$_SESSION['s1'].":00";
$s2=$_SESSION['s2'].":00";
$s3=$_SESSION['s3'].":00";
$s4=$_SESSION['s4'].":00";
$s5=$_SESSION['s5'].":00";
 
$e1=$_SESSION['e1'].":00";
$e2=$_SESSION['e2'].":00";
$e3=$_SESSION['e3'].":00";
$e4=$_SESSION['e4'].":00";
$e5=$_SESSION['e5'].":00";
$sub_id=$_SESSION['sub_id'];
//$q="SELECT MAX(ID) FROM $sub_id";

$res=mysqli_query($conn,"SELECT MAX(ID) FROM $sub_id");
$obj = mysqli_fetch_object($res);

//$obj=mysqli_fetch_field($res);
$a=$obj->ID;

$a=$a+1;

$b=$a+2;
$c=$a+3;
$d=$a+4;
$e=$a+5;

   $sql = "INSERT INTO $sub_id(ID,DATE,START_TIME,END_TIME) VALUES ('$a','$date', '$s1', '$e1'),('$a','$date', '$s2', '$e2'),('$c','$date', '$s3', '$e3'),('$d','$date', '$s4', '$e4'),('$e','$date', '$s5', '$e5')";
if ($conn->query($sql) === TRUE) {
    echo "new row created in toc_slots";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$a=$a+5;
$b=$b+5;
$c=$c+5;
$d=$d+5;
$e=$e+5;
header("Location:f_selection.html");
 
?>